import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import{ AddMovieComponent} from '../add-movie/add-movie.component';

import{ SearchMovieComponent} from '../search-movie/search-movie.component';

const routes: Routes = [
  { path: 'addMovie', component: AddMovieComponent },
  { path: 'searchMovie', component: SearchMovieComponent }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes)
  ],
   exports: [ RouterModule ],
  declarations: []
})
export class AppRoutingModule { }

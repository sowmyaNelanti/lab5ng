import { Component, OnInit } from '@angular/core';
import{FormGroup,FormControl,Validators} from '@angular/forms';
@Component({
  selector: 'app-add-movie',
  templateUrl: './add-movie.component.html',
  styleUrls: ['./add-movie.component.css']
})
export class AddMovieComponent implements OnInit {
mveName;
mveRating;
movieName="Movie Name is Required!!!";
movieRating="Rating is Required!!!";
form: FormGroup;

  constructor() { }




  ngOnInit() {

    this.form=new FormGroup({
       Mname:new FormControl('',[Validators.required,Validators.pattern('[a-zA-Z]+')]),
       Mrating:new FormControl('',[Validators.required,Validators.pattern('[0-9]+')]),
       Sgenre:new FormControl('',[Validators.required]),

})
  }
 addMve(){
//  if(this.mveName==null && this.mveRating==null)
//  {
//  this.movieName="Movie Name is Required!!!";
//  this.movieRating="Genre is Required!!!"
// }
//  else if(this.mveRating==null)
//  {
//    this.movieRating="Genre is Required!!!"
//   }
//else if()
//{document.write(Select Genre!!!)}
  }

}
